import React from "react";

import Card from "../../components/card";
import Header from "../../components/header";
import Botao from "../../components/botao";
import Container from "../../components/container";

export default function Home() {
  return (
    <div className="App">
      <Header />
      <h1>Lista de Doações</h1>
      <Container>
        <Card
          itens="Alimentos"
          descricao="Estou pedindo esses alimentos"
          doador="Vini"
        />
        <Card />
        <Card />
        <Card />
        <Card />
        <Card />
      </Container>
    </div>
  );
}
