import React from "react";
import "./Global.css";
import Card from "./components/card";
import Header from "./components/header";
import Botao from "./components/botao";
//const teste = " oi";
function App() {
  const teste = 10;
  return (
    <div className="App">
      <Header />
      <Botao cor="verde" />
      <Botao texto="Excluir" />
      <Botao texto="Alterar" />
    </div>
  );
}

export default App;
