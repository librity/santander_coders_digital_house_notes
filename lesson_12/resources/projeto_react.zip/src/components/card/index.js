import React from "react";
import "./style.css";
function Card() {
  return (
    <div>
      <h1>Component Card</h1>
    </div>
  );
}

export default Card;
