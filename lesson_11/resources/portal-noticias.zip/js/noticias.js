const API_KEY = "2daae9e6bde2452b8f56636252f80623";
const BASE_API = "http://newsapi.org/v2";
const containerDeNoticias = document.querySelector("#listaDeNoticias");
const btnTec = document.querySelector("#tec");
const btnUltimas = document.querySelector("#ultimas");
const btnAtualizar = document.querySelector("#atualizar");
let acao = "";
// function getNoticias() {
//   fetch(`${BASE_API}/top-headlines?country=br&apiKey=${API_KEY}`)
//     .then((resposta) => resposta.json())
//     .then((listaDeNoticias) => console.log(listaDeNoticias));
// }

async function getNoticias() {
  containerDeNoticias.innerHTML = "";
  const resposta = await fetch(
    `${BASE_API}/top-headlines?country=br&apiKey=${API_KEY}`
  );
  const listaDeNoticias = await resposta.json();

  listaDeNoticias.articles.forEach((noticia) => {
    let coluna = document.createElement("div");
    coluna.setAttribute("class", "col-4");

    let card = document.createElement("div");
    card.setAttribute("class", "card");

    let imgCard = document.createElement("img");
    imgCard.setAttribute("class", "card-img-top");
    imgCard.setAttribute("src", noticia.urlToImage);

    let bodyCard = document.createElement("div");
    bodyCard.setAttribute("class", "card-body");

    let titleCard = document.createElement("h5");
    titleCard.setAttribute("class", "card-title");
    titleCard.textContent = noticia.title;

    let descriptionCard = document.createElement("p");
    descriptionCard.setAttribute("class", "card-text");
    descriptionCard.textContent = noticia.description;

    let linkCard = document.createElement("a");
    linkCard.setAttribute("class", "btn btn-primary");
    linkCard.setAttribute("href", noticia.url);
    linkCard.textContent = "Ir para noticia";

    card.appendChild(imgCard);
    card.appendChild(bodyCard);
    bodyCard.appendChild(titleCard);
    bodyCard.appendChild(descriptionCard);
    bodyCard.appendChild(linkCard);

    coluna.appendChild(card);

    containerDeNoticias.appendChild(coluna);
  });
  console.log(listaDeNoticias);
}

async function getTecnologias() {
  containerDeNoticias.innerHTML = "";
  const resposta = await fetch(
    `${BASE_API}/top-headlines?country=br&category=technology&apiKey=${API_KEY}`
  );
  const listaDeNoticias = await resposta.json();
  listaDeNoticias.articles.forEach((noticia) => {
    let coluna = document.createElement("div");
    coluna.setAttribute("class", "col-4");

    let card = document.createElement("div");
    card.setAttribute("class", "card");

    let imgCard = document.createElement("img");
    imgCard.setAttribute("class", "card-img-top");
    imgCard.setAttribute("src", noticia.urlToImage);

    let bodyCard = document.createElement("div");
    bodyCard.setAttribute("class", "card-body");

    let titleCard = document.createElement("h5");
    titleCard.setAttribute("class", "card-title");
    titleCard.textContent = noticia.title;

    let descriptionCard = document.createElement("p");
    descriptionCard.setAttribute("class", "card-text");
    descriptionCard.textContent = noticia.description;

    let linkCard = document.createElement("a");
    linkCard.setAttribute("class", "btn btn-primary");
    linkCard.setAttribute("href", noticia.url);
    linkCard.textContent = "Ir para noticia";

    card.appendChild(imgCard);
    card.appendChild(bodyCard);
    bodyCard.appendChild(titleCard);
    bodyCard.appendChild(descriptionCard);
    bodyCard.appendChild(linkCard);

    coluna.appendChild(card);

    containerDeNoticias.appendChild(coluna);
  });
}

btnTec.onclick = (e) => {
  e.preventDefault();
  acao = getTecnologias;
  getTecnologias();
};

btnUltimas.onclick = (e) => {
  e.preventDefault();
  acao = getNoticias;
  getNoticias();
};

btnAtualizar.onclick = (e) => {
  acao();
};

getNoticias();
acao = getNoticias;
