// Incluindo express
const express = require("express");

// Criando o Router
const router = express.Router();

// Incluindo o StaticController
const PizzasController = require("../controllers/PizzasController");

// Criando rota get para /
router.get("/", PizzasController.listar);

// Criando rota get para /:busca
router.get("/:busca", PizzasController.buscar);

module.exports = router;
