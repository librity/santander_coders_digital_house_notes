// Incluindo express
const express = require("express");

// Criando o Router
const router = express.Router();

// Incluindo o StaticController
const StaticController = require("../controllers/StaticController");

// Criando rota get para /
router.get("/", StaticController.home);

// Criando rota get para /sobre
router.get("/sobre", StaticController.sobre);

module.exports = router;
